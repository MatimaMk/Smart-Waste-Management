
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        const errorMessage = document.getElementById('errorMessage');
    
        // Reset error message
        errorMessage.style.display = 'none';
    
        // Check for empty fields
        
        // Hardcoded credentials
    const validUsername = 'matima547@gmail.com';
    const validPassword = '123';

    if (username === validUsername && password === validPassword) {
        alert('Login successful!');
        window.location.href = "index.html"
    } else {
        errorMessage.textContent = 'Invalid username or password';
        errorMessage.style.display = 'block';
    }
  

    
});