let imageSpace = document.getElementById("uploadedImage");
let fileUpload = document.getElementById("imageUpload");

fileUpload.onchange = function() {
    imageSpace.src = URL.createObjectURL(fileUpload.files[0]);
    imageSpace.style.display = 'block';
};


